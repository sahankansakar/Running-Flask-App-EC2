# learning-flask
python, flask, sqlite3, templates

Author: Allen Detmer
Runs on an EC2 instance, configured apache server on ubuntu, with sqlite3
Interactive web for:
    1. registration page - registers a new user
    2. user basic -  details can be updated
    3. Home - after user logs in the user information is displayed with uploaded file
    4. if the user is not logged in, the user is prompted to log in
    5. count - a page for uploading a txt file and counting the words in the file
    6. For extra credit the uploaded file is displayed after the user is logged in and can be downloaded
